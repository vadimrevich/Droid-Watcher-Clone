package com.droidwatcher.security;

public class SecuriryInfo {
	public static final String GcmSenderId = "0000000000000";
	
	public static final String FormUri = "https://xxxxxx.com/report";
	public static final String FormUriBasicAuthLogin="xxxxxx";
	public static final String FormUriBasicAuthPassword="xxxxxx";
	
	public static final String openCellIdApiKey = "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx";
}
